public class CalculadoraDescontos {
    private static final double DESCONTO_PRODUTO_A = 0.1;
    private static final double DESCONTO_PRODUTO_B = 0.15;
    private static final double DESCONTO_PRODUTO_C = 0.2;
    
    public double calcularDesconto(double preco, double percentualDesconto) {
        return preco - (preco * percentualDesconto);
    }
    
    public double calcularDescontoProdutoA(double preco) {
        return calcularDesconto(preco, DESCONTO_PRODUTO_A);
    }
    
    public double calcularDescontoProdutoB(double preco) {
        return calcularDesconto(preco, DESCONTO_PRODUTO_B);
    }
    
    public double calcularDescontoProdutoC(double preco) {
        return calcularDesconto(preco, DESCONTO_PRODUTO_C);
    }
}