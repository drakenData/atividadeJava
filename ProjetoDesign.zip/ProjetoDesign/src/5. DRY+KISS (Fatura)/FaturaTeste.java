public class FaturaTeste {
    public static void main(String[] args) {
        Fatura fatura1 = new Fatura("001", "Mouse óptico", 2, 50.0);
        System.out.println("Fatura 1:");
        System.out.println("Número: " + fatura1.getNumero());
        System.out.println("Descrição: " + fatura1.getDescricao());
        System.out.println("Quantidade: " + fatura1.getQuantidade());
        System.out.println("Preço por item: R$" + fatura1.getPrecoPorItem());
        System.out.println("Total: R$" + fatura1.getTotalFatura());
        
        // Testando validações
        Fatura fatura2 = new Fatura("002", "Teclado mecânico", -1, -30.0);
        System.out.println("\nFatura 2 (com valores inválidos):");
        System.out.println("Quantidade: " + fatura2.getQuantidade());
        System.out.println("Preço por item: R$" + fatura2.getPrecoPorItem());
        System.out.println("Total: R$" + fatura2.getTotalFatura());
    }
}