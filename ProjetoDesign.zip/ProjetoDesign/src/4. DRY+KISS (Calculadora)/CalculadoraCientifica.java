public class CalculadoraCientifica extends Calculadora {
    public double raizQuadrada(double a) {
        if (a < 0) {
            throw new IllegalArgumentException("Não é possível calcular raiz quadrada de número negativo");
        }
        return Math.sqrt(a);
    }
    
    public double potencia(double base, double expoente) {
        return Math.pow(base, expoente);
    }
}