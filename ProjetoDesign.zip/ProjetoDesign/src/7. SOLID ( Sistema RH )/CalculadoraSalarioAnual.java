public class CalculadoraSalarioAnual implements CalculadoraSalario {
    @Override
    public double calcularSalarioAnual(Empregado empregado) {
        return empregado.getSalarioMensal() * 12;
    }
}
