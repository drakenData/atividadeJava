
public class EmpregadoTeste {
    public static void main(String[] args) {
        // Criando empregados
        Empregado emp1 = new Empregado("João", "Silva", 5000.0);
        Empregado emp2 = new Empregado("Maria", "Santos", 6000.0);
        
        // Usando calculadora de salário
        CalculadoraSalario calculadora = new CalculadoraSalarioAnual();
        
        // Exibindo salário anual inicial
        System.out.println("Salário anual de " + emp1.getNome() + ": R$" + calculadora.calcularSalarioAnual(emp1));
        System.out.println("Salário anual de " + emp2.getNome() + ": R$" + calculadora.calcularSalarioAnual(emp2));
        
        // Aplicando aumento
        AplicadorAumento aumento = new AumentoPorcentual(10.0);
        aumento.aplicarAumento(emp1);
        aumento.aplicarAumento(emp2);
        
        // Exibindo salário anual após aumento
        System.out.println("\nApós aumento de 10%:");
        System.out.println("Salário anual de " + emp1.getNome() + ": R$" + calculadora.calcularSalarioAnual(emp1));
        System.out.println("Salário anual de " + emp2.getNome() + ": R$" + calculadora.calcularSalarioAnual(emp2));
    }
}