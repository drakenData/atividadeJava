public interface CalculadoraSalario {
    double calcularSalarioAnual(Empregado empregado);
}