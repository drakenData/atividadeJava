public class AumentoFixo implements AplicadorAumento {
    private final double valorFixo;
    
    public AumentoFixo(double valorFixo) {
        this.valorFixo = valorFixo;
    }
    
    @Override
    public void aplicarAumento(Empregado empregado) {
        double salarioAtual = empregado.getSalarioMensal();
        empregado.setSalarioMensal(salarioAtual + valorFixo);
    }
}
