public interface AplicadorAumento {
    void aplicarAumento(Empregado empregado);
}
