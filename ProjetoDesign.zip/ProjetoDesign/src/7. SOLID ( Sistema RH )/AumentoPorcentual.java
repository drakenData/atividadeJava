public class AumentoPorcentual implements AplicadorAumento {
    private final double percentual;
    
    public AumentoPorcentual(double percentual) {
        this.percentual = percentual;
    }
    
    @Override
    public void aplicarAumento(Empregado empregado) {
        double salarioAtual = empregado.getSalarioMensal();
        double novoSalario = salarioAtual + (salarioAtual * percentual / 100);
        empregado.setSalarioMensal(novoSalario);
    }
}
