public class Main {
    public static void main(String[] args) {
        // Test implementations
        CarroPasseio carro = new CarroPasseio(1200, 180, 45000.0f, 4, 120, "Azul", "Sedan");
        carro.print();
        
    }
}