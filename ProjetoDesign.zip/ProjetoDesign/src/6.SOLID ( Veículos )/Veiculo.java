public class Veiculo {
    private int peso;
    private int velocMax;
    private float preco;
    
    public Veiculo() {
        this(0, 0, 0.0f);
    }
    
    public Veiculo(int peso, int velocMax, float preco) {
        this.peso = peso;
        this.velocMax = velocMax;
        this.preco = preco;
    }
    
    // Getters and setters
    public int getPeso() {
        return peso;
    }
    
    public void setPeso(int peso) {
        this.peso = peso;
    }
    
    public int getVelocMax() {
        return velocMax;
    }
    
    public void setVelocMax(int velocMax) {
        this.velocMax = velocMax;
    }
    
    public float getPreco() {
        return preco;
    }
    
    public void setPreco(float preco) {
        this.preco = preco;
    }
    
    public void set(int peso, int velocMax, float preco) {
        this.peso = peso;
        this.velocMax = velocMax;
        this.preco = preco;
    }
    
    public void print() {
        System.out.println("Veículo: " + peso + "kg, " + velocMax + "km/h, R$" + preco);
    }
}