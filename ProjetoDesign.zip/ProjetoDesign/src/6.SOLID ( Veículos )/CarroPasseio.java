public class CarroPasseio extends Veiculo {
    private Motor motor;
    private String cor;
    private String modelo;
    
    public CarroPasseio() {
        super();
        this.motor = new Motor();
        this.cor = "";
        this.modelo = "";
    }
    
    public CarroPasseio(int peso, int velocMax, float preco, int numCilindro, int potencia, String cor, String modelo) {
        super(peso, velocMax, preco);
        this.motor = new Motor(numCilindro, potencia);
        this.cor = cor;
        this.modelo = modelo;
    }
    
    // Getters and setters
    public Motor getMotor() {
        return motor;
    }
    
    public void setMotor(Motor motor) {
        this.motor = motor;
    }
    
    public String getCor() {
        return cor;
    }
    
    public void setCor(String cor) {
        this.cor = cor;
    }
    
    public String getModelo() {
        return modelo;
    }
    
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    @Override
    public void print() {
        super.print();
        motor.print();
        System.out.println("Carro de Passeio: " + modelo + ", cor " + cor);
    }
}
