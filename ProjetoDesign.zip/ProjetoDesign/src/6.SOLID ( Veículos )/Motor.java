public class Motor {
    private int numCilindro;
    private int potencia;
    
    public Motor() {
        this(0, 0);
    }
    
    public Motor(int numCilindro, int potencia) {
        this.numCilindro = numCilindro;
        this.potencia = potencia;
    }
    
    // Getters and setters
    public int getNumCilindro() {
        return numCilindro;
    }
    
    public void setNumCilindro(int numCilindro) {
        this.numCilindro = numCilindro;
    }
    
    public int getPotencia() {
        return potencia;
    }
    
    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }
    
    public void set(int numCilindro, int potencia) {
        this.numCilindro = numCilindro;
        this.potencia = potencia;
    }
    
    public void print() {
        System.out.println("Motor: " + numCilindro + " cilindros, " + potencia + " HP");
    }
}
