public class ValidadorSenha {
    public boolean validarSenha(String senha) {
        // Verificar tamanho mínimo
        if (senha.length() < 8) {
            return false;
        }
        
        // Verificar pelo menos um número
        boolean temNumero = false;
        for (char c : senha.toCharArray()) {
            if (Character.isDigit(c)) {
                temNumero = true;
                break;
            }
        }
        if (!temNumero) {
            return false;
        }
        
        // Verificar pelo menos uma letra maiúscula
        boolean temMaiuscula = false;
        for (char c : senha.toCharArray()) {
            if (Character.isUpperCase(c)) {
                temMaiuscula = true;
                break;
            }
        }
        
        return temMaiuscula;
    }
}